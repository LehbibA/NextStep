<?php
define('SECRET_KEY', 'MaCleJWTsuperSecrete2024');
